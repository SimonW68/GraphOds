//
//  VueLiens.swift
//  graphOds
//
//  Created by Simon Wintz on 09/02/2025.
//

import Foundation
import SwiftUI

public struct LinksView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(entity: Link.entity(), sortDescriptors: [])
    private var liens: FetchedResults<Link>
    
    public var body: some View {
        Text("\(liens.count) links")
            .fontWeight(.bold)
        List(liens) { lien in
            Text("\(lien.back!.draw!) \(lien.letter!) \((lien.gives != nil) ? lien.gives!.draw! : "" )" )//: \()")
                .dynamicTypeSize(.xxxLarge)
        }
    }
}
