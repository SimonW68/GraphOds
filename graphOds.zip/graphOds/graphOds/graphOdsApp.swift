//
//  graphOdsApp.swift
//  graphOds
//
//  Created by Simon Wintz on 24/01/2025.
//

import SwiftUI

let DATA_LODADED = "data-loaded"
let ALPHABET : String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

@main
struct graphOdsApp: App {
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
            .environment(\.managedObjectContext, persistenceController.container.viewContext)        }
    }
}
