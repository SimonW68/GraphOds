//
//  ContentView.swift
//  graphOds
//
//  Created by Simon Wintz on 24/01/2025.
//

import SwiftUI
import CoreData

let INPUT_FILE : String = "ods9"

struct ContentView: View {
    @State var count = 0
    @State var displayLiens : Bool = false
    @State var linkTable : [Link] = []
    @AppStorage(DATA_LODADED) var dataAlreadyLoaded : Bool = false
    @Environment(\.managedObjectContext) private var viewContext
    var body: some View {
        VStack(alignment: .center) {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            LinksView()
        }
        .padding()
        .onAppear {
            if !dataAlreadyLoaded {
                loadDic()
                createLinks()
                updateLinks()
            }
        }
    }
    
    func updateLinks() {
        var erreur = "fetch request <Link>"
        let request: NSFetchRequest<Link> = Link.fetchRequest()
        request.entity = Link.entity()
        print("Running patch...")
        do {
            request.predicate = NSPredicate(format: "gives == nil")
            let links = try viewContext.fetch(request)
            for link in links {
                let baseDraw = link.back!.draw!
                print("\(baseDraw) \(link.letter!)")
                let augmDrawLetters = String((baseDraw + link.letter!).sorted())
                if let augmDraw = getDraw(drawLetters: augmDrawLetters) {
                    viewContext.perform {
                        let updateLink = link as NSManagedObject
                        updateLink.setValue(augmDraw, forKey: "gives")
                        erreur = " saving \(augmDraw.draw!) \(link.letter!)"
                        do {
                            try viewContext.save()
                        } catch {
                            print("Error updating link")
                        }
                    }
                }
            }
        } catch {
            print("Error " + erreur)
        }
    }
    
    func createLinks() {
        var erreur = " fetch request <Draw>"
        let request: NSFetchRequest<Draw> = Draw.fetchRequest()
        request.entity = Draw.entity()
        request.predicate = NSPredicate(value: true)
        print("Building relationships...")
        do {
            let draws = try viewContext.fetch(request)
            count = draws.count
            for draw in draws {
                print("\(count) - \(draw.draw!)")
                linkTable.removeAll()
                for letter in ALPHABET {
                    let drawLettersPlus = String((draw.draw! + String(letter)).sorted()) // draw with one more letter
                    if let drawPlus = draws.first(where: { $0.draw == drawLettersPlus }) { // look for Draw entity that matches augmented draw
                        let linkItem = Link(context: viewContext) // if found, create new link based on letter with relationship to augmented draw
                        linkItem.letter = String(letter)
                        linkItem.gives = drawPlus
                        erreur = " saving \(draw.draw!) + \(letter)"
                        try viewContext.save()
                        linkTable.append(linkItem) // saves link to populate the one-to-many relationship of the initial draw, once the alphabet is through
                    }
                }
                let drawUpdate = draw as NSManagedObject // populate the one-to-many relationship of the initial draw
                let linkSet = Set(linkTable) as NSSet
                drawUpdate.setValue(linkSet, forKey: "plus")
                erreur = " saving \(draw.draw!) links plus"
                try viewContext.save()
                count -= 1 // next draw
            }
        } catch {
            print("Error " + erreur)
        }
        print("Graph completed")
    }
    
    func loadDic() {
        print("Loading dictionary...")
        dataAlreadyLoaded.toggle()
        guard let url = Bundle.main.url(forResource: INPUT_FILE, withExtension: "txt") else {
            fatalError("\(INPUT_FILE).txt not found")
        }
        if let dico = try? String(contentsOf: url, encoding: String.Encoding.utf8 ) {
            let lines = dico.split(separator: "\r\n")
            for line in lines {
                let lineArray = line.split(separator: " ")
                print("\(lineArray[0])") // word
                let wordSorted = String(lineArray[0].sorted())
                let draw = getDraw(drawLetters: wordSorted) ?? addDraw(drawLetters: wordSorted) // look if draw already exists, otherwise create new one.
                let wordItem = Word(context: viewContext) // create word entry with to-one-relationship to draw
                wordItem.spelling = String(lineArray[0])
                wordItem.optComp = (Int(String(lineArray[1])) == 1)
                wordItem.sort = draw
                do {
                    try viewContext.save()
                } catch {
                    print("Errort saving ods9: \(error)")
                }
            }
        }
        print("Dic loaded")
    }
    
    func addDraw(drawLetters: String) -> Draw {
        let newDraw = Draw(context: viewContext)
        newDraw.draw = drawLetters
        return(newDraw)
    }
    
    func getDraw(drawLetters: String) -> Draw? {
        let request: NSFetchRequest<Draw> = Draw.fetchRequest()
        request.entity = Draw.entity()
        request.predicate = NSPredicate(format: "draw == %@", drawLetters)
        do {
            let drw = try viewContext.fetch(request)
            return drw.isEmpty ? nil : drw[0]
        } catch {
            print("Error fetching Draw")
            return nil
        }
    }
}

