//
//  graphOdsTests.swift
//  graphOdsTests
//
//  Created by Simon Wintz on 24/01/2025.
//

import Testing
@testable import graphOds

struct graphOdsTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
